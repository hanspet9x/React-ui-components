import React from 'react';

const WindowContent = ()=>{

    return(
        <section></section>
    )
}

export default WindowContent;