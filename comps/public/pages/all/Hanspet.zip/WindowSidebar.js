import React from 'react';

const WindowSidebar = ()=>{

    return(
        <nav></nav>
    )
}

export default WindowSidebar;