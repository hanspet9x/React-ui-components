import React from 'react';

const WindowSidebar = ()=>{

    return(
        <section></section>
    )
}

export default WindowSidebar;